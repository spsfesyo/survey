<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin-dashboard')); ?>">

                <img src="<?php echo e(asset('img/logo_blesscon.svg')); ?>" alt="Logo" style="height: 40px;">
            </a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">SPS</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li class="nav-item dropdown ">
                <a href="<?php echo e(route('admin-dashboard')); ?>"
                    class="nav-link "><i class="fas fa-fire"></i><span>Dashboard</span></a>
                
            </li>

            <li class="<?php echo e(Request::is('admin-statistik') ? 'active' : ''); ?>">
                <a class="nav-link"
                    href="<?php echo e(route('admin-statistik')); ?>"><i class="fas fa-calculator"></i> <span>Statistik</span></a>
            </li>

            
           
    </aside>
</div>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/sidebar.blade.php ENDPATH**/ ?>