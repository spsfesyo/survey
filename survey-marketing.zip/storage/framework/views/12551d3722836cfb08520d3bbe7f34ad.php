<table>
    <thead>
        <tr>
            <td>No</td>
            <th>Tanggal</th>
            

            <?php $__currentLoopData = $pertanyaanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($pertanyaan->pertanyaan); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $respondents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respondent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($respondent->created_at)->format('d-m-Y')); ?></td>
                

                <?php $__currentLoopData = $pertanyaanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // Cek apakah tipe pertanyaan adalah 5 (mengambil dari kolom lain di respondent)
                    if (
                        $pertanyaan->master_tipe_pertanyaan_id == 5 &&
                        $pertanyaan->reference
                    ) {
                        switch ($pertanyaan->reference) {
                            case 'provinsi_id':
                                $jawaban =
                                    $respondent->provinsi->nama_provinsi ?? '-';
                                break;
                            case 'kota_id':
                                $jawaban = $respondent->kota->kota ?? '-';
                                break;
                            case 'jenis_pertanyaan_id':
                                $jawaban =
                                    $respondent->JenisPertanyaan
                                        ->jenis_pertanyaan ?? '-';
                                break;
                            default:
                                $jawaban =
                                    $respondent->{$pertanyaan->reference} ?? '-';
                                break;
                        }
                    } else {
                        // Ambil jawaban dari relasi answers
                        $jawaban = $respondent->answers
                            ->where('master_pertanyaan_id', $pertanyaan->id)
                            ->map(function ($a) {
                                $option = $a->options->options ?? null;

                                // Jika jawaban adalah "Other" / "Lainnya", gunakan input teks-nya
                                if (
                                    strtolower($option) === 'other' ||
                                    strtolower($option) === 'lainnya'
                                ) {
                                    return $a->lainnya ?? 'Other';
                                }

                                // Jika tidak ada relasi option, gunakan jawaban_teks atau lainnya
                                return $option ?? ($a->jawaban_teks ?? $a->lainnya);
                            })
                            ->implode(', ');
                    }
                ?>
                <td><?php echo e($jawaban); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/Admin/Exports/excel.blade.php ENDPATH**/ ?>