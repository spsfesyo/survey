<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['chartId', 'labels', 'values', 'label']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['chartId', 'labels', 'values', 'label']); ?>
<?php foreach (array_filter((['chartId', 'labels', 'values', 'label']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div style="position: relative; height: 300px;">
    <canvas id="<?php echo e($chartId); ?>"></canvas>
</div>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0"></script>
    <script>
        (function() {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded',
                    initPieChart_<?php echo e(str_replace(['-', '.', ' '], '_', $chartId)); ?>);
            } else {
                initPieChart_<?php echo e(str_replace(['-', '.', ' '], '_', $chartId)); ?>();
            }

            function initPieChart_<?php echo e(str_replace(['-', '.', ' '], '_', $chartId)); ?>() {
                try {
                    const ctx = document.getElementById('<?php echo e($chartId); ?>');
                    if (!ctx) {
                        console.warn('Canvas element <?php echo e($chartId); ?> not found');
                        return;
                    }

                    const labels = <?php echo json_encode($labels); ?>;
                    const values = <?php echo json_encode($values); ?>;

                    const validLabels = [];
                    const validData = [];

                    for (let i = 0; i < labels.length; i++) {
                        if (values[i] !== null && values[i] !== undefined && values[i] > 0) {
                            validLabels.push(labels[i]);
                            validData.push(values[i]);
                        }
                    }

                    if (validData.length === 0) {
                        validLabels.push('Tidak ada data');
                        validData.push(1);
                    }

                    const colors = [
                        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
                        '#9966FF', '#FF9F40', '#C9CBCF', '#4BC0C0',
                        '#FF6384', '#36A2EB', '#FFCE56'
                    ];
                    const backgroundColors = validLabels.map((_, i) => colors[i % colors.length]);

                    new Chart(ctx.getContext('2d'), {
                        type: 'pie',
                        data: {
                            labels: validLabels,
                            datasets: [{
                                data: validData,
                                backgroundColor: backgroundColors,
                                borderColor: backgroundColors,
                                borderWidth: 2,
                                hoverBorderWidth: 3
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    position: 'bottom',
                                    labels: {
                                        boxWidth: 12,
                                        padding: 10,
                                        usePointStyle: true,
                                        font: {
                                            size: 11
                                        }
                                    }
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            const label = context.label || '';
                                            const value = context.parsed;
                                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                            const percentage = total > 0 ? ((value / total) * 100).toFixed(
                                                1) : 0;
                                            return label + ': ' + value + ' (' + percentage + '%)';
                                        }
                                    }
                                },
                                datalabels: {
                                    color: '#fff',
                                    font: {
                                        weight: 'bold',
                                        size: 10
                                    },
                                    formatter: function(value, context) {
                                        const data = context.chart.data.datasets[0].data;
                                        const total = data.reduce((a, b) => a + b, 0);
                                        const percent = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                        return percent + '%';
                                    },
                                    display: function(context) {
                                        // Tampilkan label hanya jika value > 0
                                        return context.dataset.data[context.dataIndex] > 0;
                                    }
                                }
                            }
                        },
                        plugins: [ChartDataLabels]
                    });

                    console.log('Pie Chart <?php echo e($chartId); ?> rendered successfully');
                } catch (error) {
                    console.error('Error rendering pie chart <?php echo e($chartId); ?>:', error);
                }
            }
        })();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/charts/pie.blade.php ENDPATH**/ ?>