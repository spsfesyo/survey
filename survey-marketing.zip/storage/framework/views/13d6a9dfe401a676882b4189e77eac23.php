<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap-social/bootstrap-social.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card card-primary">
        <div class="card-header">
            <h4>Masukkan Email Anda</h4>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('submit-email')); ?>" class="needs-validation" novalidate="">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" type="email" class="form-control" name="email" tabindex="1" required
                        autofocus>
                    <div class="invalid-feedback">
                        Email tidak boleh kosong
                    </div>
                </div>

                

                <div class="form-group">
                    
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                        Kirim
                    </button>
                </div>
            </form>
            

        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- JS Libraies -->
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '<?php echo e(session('success')); ?>',
            });
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'email telah terdaftar dan sudah pernah mengisi form surey gunakan email yang lain',
                text: '<?php echo e(session('error')); ?>',
            });
        </script>
    <?php endif; ?>

    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\survey-marketing\resources\views/home.blade.php ENDPATH**/ ?>