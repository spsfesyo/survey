<?php $__env->startSection('title', 'General Dashboard'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('library/jqvmap/dist/jqvmap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/summernote/dist/summernote-bs4.min.css')); ?>">

    <style>
        .thead-sticky th {
            background: #fff;
            position: sticky;
            top: 0;
            z-index: 10;
            border-bottom: 2px solid #dee2e6;
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
        }

        .pie-chart-question {
            font-weight: 500;
            font-size: 14px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Statistik</h1>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12 col-sm-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="mb-0">Tabel Hasil Data Respondent</h4>
                                <a href="<?php echo e(route('export.respondent')); ?>" class="btn btn-icon icon-left btn-success">
                                    <i class="fas fa-download"></i> Excel
                                </a>
                            </div>

                            <div class="card-body text-center">
                                <div class="table-responsive" style="max-height: 500px; overflow: auto;">
                                    <table class="table table-bordered table-md" style="min-width: 1200px;">
                                        <thead class="thead-sticky bg-light">
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <!-- <th>Nama Respondent</th>
                                                                                                                                                                                                                                                                             <th>Provinsi Lokasi Toko</th>
                                                                                                                                                                                                                                                                             <th>Kota / Kabupaten Lokasi Toko</th>
                                                                                                                                                                                                                                                                             <th>Email Responden</th>
                                                                                                                                                                                                                                                                             <th>Alamat Toko</th>
                                                                                                                                                                                                                                                                             <th>Nama Toko</th>
                                                                                                                                                                                                                                                                             <th>Nomor Telepon</th>
                                                                                                                                                                                                                                                                             <th>Selama ini Anda membeli merek apa dari Produk Bata Ringan kami?</th> -->

                                                <?php $__currentLoopData = $pertanyaanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th><?php echo e($pertanyaan->pertanyaan); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $respondents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respondent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td> <?php echo e($loop->iteration + ($respondents->currentPage() - 1) * $respondents->perPage()); ?>

                                                    </td> 
                                                    <td><?php echo e(\Carbon\Carbon::parse($respondent->created_at)->format('d-m-Y')); ?>

                                                    </td>
                                                    <!-- <td><?php echo e($respondent->nama_respondent); ?></td>
                                                                                                                                                                                                                                                                                 <td><?php echo e($respondent->provinsi->nama_provinsi ?? '-'); ?></td>
                                                                                                                                                                                                                                                                                 <td><?php echo e($respondent->kota->kota ?? '-'); ?></td>
                                                                                                                                                                                                                                                                                 <td><?php echo e($respondent->email_respondent); ?></td>
                                                                                                                                                                                                                                                                                 <td><?php echo e($respondent->alamat_toko_respondent); ?></td>
                                                                                                                                                                                                                                                                                 <td><?php echo e($respondent->nama_toko_respondent); ?></td>
                                                                                                                                                                                                                                                                                 <td><?php echo e($respondent->telepone_respondent); ?></td>
                                                                                                                                                                                                                                                                                 <td><?php echo e($respondent->JenisPertanyaan->jenis_pertanyaan ?? '-'); ?></td> -->

                                                    <?php $__currentLoopData = $pertanyaanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            // Cek apakah tipe pertanyaan adalah 5 (mengambil dari kolom lain di respondent)
                                                            if (
                                                                $pertanyaan->master_tipe_pertanyaan_id == 5 &&
                                                                $pertanyaan->reference
                                                            ) {
                                                                switch ($pertanyaan->reference) {
                                                                    case 'provinsi_id':
                                                                        $jawaban =
                                                                            $respondent->provinsi->nama_provinsi ?? '-';
                                                                        break;
                                                                    case 'kota_id':
                                                                        $jawaban = $respondent->kota->kota ?? '-';
                                                                        break;
                                                                    case 'jenis_pertanyaan_id':
                                                                        $jawaban =
                                                                            $respondent->JenisPertanyaan
                                                                                ->jenis_pertanyaan ?? '-';
                                                                        break;
                                                                    default:
                                                                        $jawaban =
                                                                            $respondent->{$pertanyaan->reference} ??
                                                                            '-';
                                                                        break;
                                                                }
                                                            } else {
                                                                // Ambil jawaban dari relasi answers
                                                                $jawaban = $respondent->answers
                                                                    ->where('master_pertanyaan_id', $pertanyaan->id)
                                                                    ->map(function ($a) {
                                                                        $option = $a->options->options ?? null;

                                                                        // Jika jawaban adalah "Other" / "Lainnya", gunakan input teks-nya
                                                                        if (
                                                                            strtolower($option) === 'other' ||
                                                                            strtolower($option) === 'lainnya'
                                                                        ) {
                                                                            return $a->lainnya ?? 'Other';
                                                                        }

                                                                        // Jika tidak ada relasi option, gunakan jawaban_teks atau lainnya
                                                                        return $option ??
                                                                            ($a->jawaban_teks ?? $a->lainnya);
                                                                    })
                                                                    ->implode(', ');
                                                            }
                                                        ?>
                                                        <td><?php echo e($jawaban); ?></td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <div class="d-inline-block">
                                    <?php echo e($respondents->appends(request()->except('tabel'))->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="mb-0">Diagram Lingkaran Data Respondent</h4>
                                <button type="button" class="btn btn-info" onclick="downloadAllCharts('pie')">
                                    <i class="fas fa-download"></i> Download Semua Diagram Lingkaran (.zip)
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <?php $__currentLoopData = $chartPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-6 mb-4">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h6 class="mb-0"><?php echo e($chart['label']); ?></h6>
                                                </div>
                                                <div class="card-body">
                                                    <?php if (isset($component)) { $__componentOriginaldc4c3158188b769cd87510448171cb0b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc4c3158188b769cd87510448171cb0b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.charts.pie','data' => ['chartId' => $chart['chartId'],'labels' => $chart['labels'],'values' => $chart['values'],'label' => ''.e($chart['label']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('charts.pie'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['chartId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chart['chartId']),'labels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chart['labels']),'values' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chart['values']),'label' => ''.e($chart['label']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc4c3158188b769cd87510448171cb0b)): ?>
<?php $attributes = $__attributesOriginaldc4c3158188b769cd87510448171cb0b; ?>
<?php unset($__attributesOriginaldc4c3158188b769cd87510448171cb0b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc4c3158188b769cd87510448171cb0b)): ?>
<?php $component = $__componentOriginaldc4c3158188b769cd87510448171cb0b; ?>
<?php unset($__componentOriginaldc4c3158188b769cd87510448171cb0b); ?>
<?php endif; ?>
                                                    <?php if(count($chart['labels']) === 1 && $chart['labels'][0] === 'Tidak ada data'): ?>
                                                        <p class="text-muted mt-2">Belum ada data jawaban untuk pertanyaan
                                                            ini.</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>


                                <div class="d-flex justify-content-center">
                                    <?php echo e($chartPaginated->appends(request()->except('chart'))->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="mb-0">Diagram Batang Data Respondent</h4>
                                <button type="button" class="btn btn-success" onclick="downloadAllCharts('bar')">
                                    <i class="fas fa-download"></i> Download Semua Diagram Batang (.zip)
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <?php $__currentLoopData = $barChartPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barChart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-6 mb-4">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h6 class="mb-0"><?php echo e($barChart['label']); ?></h6>
                                                </div>
                                                <script>
                                                    console.log('Data Barchart untuk <?php echo e($barChart['label']); ?>:',
                                                        JSON.parse('<?php echo json_encode($barChart, 15, 512) ?>'));
                                                </script>
                                                <div class="card-body">
                                                    <?php if($barChart['isEmpty']): ?>
                                                        <p class="text-muted">Tidak ada data untuk ditampilkan</p>
                                                    <?php else: ?>
                                                        <?php if (isset($component)) { $__componentOriginalf22e46971404621943cbf7aad151504f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf22e46971404621943cbf7aad151504f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.charts.bar','data' => ['chartId' => 'bar-chart-' . $barChart['questionId'],'labels' => $barChart['labels'],'values' => $barChart['values'],'labelName' => $barChart['label']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('charts.bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['chartId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('bar-chart-' . $barChart['questionId']),'labels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($barChart['labels']),'values' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($barChart['values']),'labelName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($barChart['label'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf22e46971404621943cbf7aad151504f)): ?>
<?php $attributes = $__attributesOriginalf22e46971404621943cbf7aad151504f; ?>
<?php unset($__attributesOriginalf22e46971404621943cbf7aad151504f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf22e46971404621943cbf7aad151504f)): ?>
<?php $component = $__componentOriginalf22e46971404621943cbf7aad151504f; ?>
<?php unset($__componentOriginalf22e46971404621943cbf7aad151504f); ?>
<?php endif; ?>
                                                    <?php endif; ?>
                                                    <div class="mt-2 text-center small">
                                                        Total Responden: <?php echo e($barChart['totalResponses'] ?? 0); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                
                                <div class="d-flex justify-content-center">
                                    <?php echo e($barChartPaginated->appends(request()->except('barchart'))->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


    <div id="chartDownloadArea" style="position: absolute; left: -9999px; top: 0;">
        <?php $__currentLoopData = $chartDataAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-title="<?php echo e($chart['label']); ?>">
                <?php if (isset($component)) { $__componentOriginaldc4c3158188b769cd87510448171cb0b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc4c3158188b769cd87510448171cb0b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.charts.pie','data' => ['chartId' => 'hidden_pie_' . $chart['chartId'],'labels' => $chart['labels'],'values' => $chart['values'],'label' => ''.e($chart['label']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('charts.pie'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['chartId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('hidden_pie_' . $chart['chartId']),'labels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chart['labels']),'values' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chart['values']),'label' => ''.e($chart['label']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc4c3158188b769cd87510448171cb0b)): ?>
<?php $attributes = $__attributesOriginaldc4c3158188b769cd87510448171cb0b; ?>
<?php unset($__attributesOriginaldc4c3158188b769cd87510448171cb0b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc4c3158188b769cd87510448171cb0b)): ?>
<?php $component = $__componentOriginaldc4c3158188b769cd87510448171cb0b; ?>
<?php unset($__componentOriginaldc4c3158188b769cd87510448171cb0b); ?>
<?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $barChartDataAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barChart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-title="<?php echo e($barChart['label']); ?>">
                <?php if (isset($component)) { $__componentOriginalf22e46971404621943cbf7aad151504f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf22e46971404621943cbf7aad151504f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.charts.bar','data' => ['chartId' => 'hidden_bar_' . $barChart['questionId'],'labels' => $barChart['labels'],'values' => $barChart['values'],'labelName' => $barChart['label']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('charts.bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['chartId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('hidden_bar_' . $barChart['questionId']),'labels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($barChart['labels']),'values' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($barChart['values']),'labelName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($barChart['label'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf22e46971404621943cbf7aad151504f)): ?>
<?php $attributes = $__attributesOriginalf22e46971404621943cbf7aad151504f; ?>
<?php unset($__attributesOriginalf22e46971404621943cbf7aad151504f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf22e46971404621943cbf7aad151504f)): ?>
<?php $component = $__componentOriginalf22e46971404621943cbf7aad151504f; ?>
<?php unset($__componentOriginalf22e46971404621943cbf7aad151504f); ?>
<?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- ZIP Download Libraries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.7.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>


    

    

    <script>
        function downloadAllCharts(type) {
            const zip = new JSZip();
            const canvases = document.querySelectorAll(`#chartDownloadArea canvas[id^="hidden_${type}_"]`);

            if (canvases.length === 0) {
                alert('Tidak ada chart untuk di-download!');
                return;
            }

            let processed = 0;

            canvases.forEach((canvas, index) => {
                const chartWrapper = canvas.closest('div[data-title]');
                const title = chartWrapper ? chartWrapper.getAttribute('data-title') : `Pertanyaan ${index + 1}`;

                // Buat canvas gabungan
                const combinedCanvas = document.createElement('canvas');
                const originalWidth = canvas.width;
                const originalHeight = canvas.height;
                const titleHeight = 60;

                combinedCanvas.width = originalWidth;
                combinedCanvas.height = originalHeight + titleHeight;

                const ctx = combinedCanvas.getContext('2d');

                // Background putih
                ctx.fillStyle = '#fff';
                ctx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height);

                // Tulis judul
                ctx.fillStyle = '#000';
                ctx.font = 'bold 20px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'top';

                // Bagi teks jadi 2 baris kalau terlalu panjang (optional, atau Anda mau saya bantu ini?)
                wrapText(ctx, title, originalWidth / 2, 10, originalWidth - 40, 24);

                // Gambar chart di bawah judul
                ctx.drawImage(canvas, 0, titleHeight);

                setTimeout(() => {
                    combinedCanvas.toBlob(blob => {
                        if (blob) {
                            zip.file(`chart_${type}_${index + 1}.jpg`, blob);
                        } else {
                            console.warn(`Chart ${index + 1} gagal dikonversi`);
                        }

                        processed++;
                        if (processed === canvases.length) {
                            zip.generateAsync({
                                type: "blob"
                            }).then(content => {
                                saveAs(content, `${type}_charts_with_titles.zip`);
                            });
                        }
                    }, 'image/jpeg', 0.95);
                }, 300);
            });
        }

        // Fungsi bantu untuk membungkus teks jika terlalu panjang
        function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
            const words = text.split(' ');
            let line = '';

            for (let n = 0; n < words.length; n++) {
                const testLine = line + words[n] + ' ';
                const metrics = ctx.measureText(testLine);
                const testWidth = metrics.width;

                if (testWidth > maxWidth && n > 0) {
                    ctx.fillText(line, x, y);
                    line = words[n] + ' ';
                    y += lineHeight;
                } else {
                    line = testLine;
                }
            }
            ctx.fillText(line, x, y);
        }
    </script>




    <!-- Custom Diagram Page Script -->
    
    

    

    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\survey-marketing\resources\views/Admin/admin-statistik.blade.php ENDPATH**/ ?>