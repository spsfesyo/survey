<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title></title>

    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- CSS Libraries -->

    <style>
        body {
            background-image: linear-gradient(120deg, #e0c3fc 0%, #8ec5fc 100%) !important;
        }

        .section {
            background-color: transparent !important;
        }
    </style>

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">

    <!-- Start GA -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-94034622-3');
    </script>
    <!-- /END GA -->
</head>

<body>
    <div id="app">
        <section class="section">
            <div class="container mt-5">
                <div class="row">
                    <div
                        class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
                        <div class="login-brand">
                            <img src="<?php echo e(asset('img/logo_blesscon.svg')); ?>" alt="logo" width="300">
                        </div>

                        <div class="card card-primary">

                            <div class="card-header">
                                <h4>Kualitas Produk Bata Ringan (Merek Blesscon atau Superior)</h4>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="form-group">

                                        
                                        <label style="font-weight:bold; font-size:0.9rem;">Bagaimana kualitas strength
                                            (daya tahan) Produk Bata Ringan kami menurut Anda? (* semakin kekanan
                                            semakin kuat)</label>
                                        <div class="d-flex justify-content-center gap-2 mt-2">
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline1" name="customRadioInline1"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline1"
                                                    style="font-weight: 600;">1</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline2" name="customRadioInline1"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline2"
                                                    style="font-weight: 600;">2</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline3" name="customRadioInline1"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline3"
                                                    style="font-weight: 600;">3</label>
                                            </div>
                                        </div>

                                        
                                        <div class="form-group" style="margin-top:15px; font-weight:600;">
                                            <label class="d-block" style="font-weight:Bold; font-size: 0.85rem;">Berapa
                                                pcs (biji) Produk Bata Ringan kami yang pecah/rusak dalam 1 kali
                                                pengiriman?</label>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="customRadio6" name="customRadio"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadio6"
                                                    style="font-weight:bold;">
                                                    < 10 pcs </label>
                                            </div>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="customRadio7" name="customRadio"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadio7"
                                                    style="font-weight:bold;">
                                                    10-25 pcs </label>
                                            </div>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="customRadio8" name="customRadio"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadio8"
                                                    style="font-weight:bold;">
                                                    25-50 pcs </label>
                                            </div>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="customRadio9" name="customRadio"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadio9"
                                                    style="font-weight:bold;">
                                                    > 50 pcs </label>
                                            </div>
                                        </div>
                                        
                                        <label style="font-weight:bold; font-size:0.9rem;">Bagaimana kualitas warna
                                            Produk Bata Ringan kami menurut Anda? (* semakin kekanan semakin
                                            putih)</label>
                                        <div class="d-flex justify-content-center gap-2 mt-2">
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline4" name="customRadioInline1"
                                                    class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline4"
                                                    style="font-weight: 600;">1</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline5"
                                                    name="customRadioInline1" class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline5"
                                                    style="font-weight: 600;">2</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline6"
                                                    name="customRadioInline1" class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline6"
                                                    style="font-weight: 600;">3</label>
                                            </div>
                                        </div>

                                        
                                        <label style="font-weight:bold; font-size:0.9rem;">Bagaimana kualitas warna
                                            Produk Bata Ringan kami menurut Anda? (* semakin kekanan semakin
                                            presisi)</label>
                                        <div class="d-flex justify-content-center gap-2 mt-2">
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline7"
                                                    name="customRadioInline1" class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline7"
                                                    style="font-weight: 600;">1</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadioInline8"
                                                    name="customRadioInline1" class="custom-control-input">
                                                <label class="custom-control-label" for="customRadioInline8"
                                                    style="font-weight: 600;">2</label>
                                            </div>
                                        </div>

                                        
                                        <div class="form-group" style="margin-top:15px; font-weight:600;">
                                            <label class="d-block" style="font-weight:Bold; font-size: 0.85rem;">
                                                Merek Bata Ringan apa yang memiliki kualitas bata terbaik di daerah Anda? (Mohon memilih 3 merek dengan kualitas bata terbaik di daerah Anda)
                                            </label>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="checkbox1">
                                                <label class="form-check-label" for="checkbox1"
                                                    style="font-weight:bold;">
                                                    Blesscon
                                                </label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="checkbox2">
                                                <label class="form-check-label" for="checkbox2"
                                                    style="font-weight:bold;">
                                                    Superior
                                                </label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="checkbox3">
                                                <label class="form-check-label" for="checkbox3"
                                                    style="font-weight:bold;">
                                                    Bricon
                                                </label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="checkbox4">
                                                <label class="form-check-label" for="checkbox4"
                                                    style="font-weight:bold;">
                                                    Citicon
                                                </label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="checkbox5">
                                                <label class="form-check-label" for="checkbox5"
                                                    style="font-weight:bold;">
                                                    Fastcon
                                                </label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="checkbox6">
                                                <label class="form-check-label" for="checkbox6"
                                                    style="font-weight:bold;">
                                                    Focon
                                                </label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="checkbox7">
                                                <label class="form-check-label" for="checkbox7"
                                                    style="font-weight:bold;">
                                                    Grand Elephant
                                                </label>
                                            </div>

                                            <div class="form-check d-flex align-items-center">
                                                <input class="form-check-input" type="checkbox" id="checkbox8">
                                                <label class="form-check-label ms-2 me-2" for="checkbox8"
                                                    style="font-weight:bold;">
                                                    Other:
                                                </label>
                                                <input type="text" class="form-control"
                                                    style="border: none; border-bottom: 1px solid #ccc; border-radius: 0; padding-left: 5px; box-shadow: none; max-width: 200px;"
                                                    placeholder="">
                                            </div>
                                        </div>
                                    </div>
                                        <div class="form-group text-center">
                                            <button type="submit" class="btn btn-lg btn-round btn-primary">
                                                Subscribe
                                            </button>
                                        </div>
                                </form>
                            </div>
                        </div>
                        <div class="simple-footer">
                            Copyright &copy; Stisla 2018
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('library/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/popper.js/dist/umd/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('library/tooltip.js/dist/umd/tooltip.js')); ?>"></script>
    <script src="<?php echo e(asset('library/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/jquery.nicescroll/dist/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/stisla.js')); ?>"></script>

    <!-- JS Libraies -->

    <!-- Page Specific JS File -->

    <!-- Template JS File -->
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

</html>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/form-pertanyaan1.blade.php ENDPATH**/ ?>