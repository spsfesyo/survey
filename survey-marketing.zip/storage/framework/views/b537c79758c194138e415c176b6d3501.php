<?php
    $user = Auth::user();
?>

<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    
        <ul class="navbar-nav mr-3">
            <li>
                <a href="#" data-toggle="sidebar" class="nav-link nav-link-lg">
                    <i class="fas fa-bars"></i>
                </a>
            </li>

            <li class="dropdown">
                <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                    <img alt="image" src="<?php echo e(asset('img/avatar/avatar-1.png')); ?>" class="rounded-circle mr-1">
                    <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e($user->name ?? 'Pengguna'); ?></div>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-divider"></div>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin: 0;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item has-icon text-danger" style="width: 100%; text-align: left;">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </form>
                </div>
            </li>
        </ul>
    
</nav>



<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/header.blade.php ENDPATH**/ ?>