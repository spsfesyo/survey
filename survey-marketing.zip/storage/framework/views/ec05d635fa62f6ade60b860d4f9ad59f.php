<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Form Pertanyaan</title>

    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- CSS Libraries -->
    <style>
        body {
            background-image: linear-gradient(120deg, #e0c3fc 0%, #8ec5fc 100%) !important;
        }

        .section {
            background-color: transparent !important;
        }
    </style>
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">

    <!-- Start GA -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-94034622-3');
    </script>
    <!-- /END GA -->
</head>

<body>
    <div id="app">
        <section class="section">
            <div class="container mt-5">
                <div class="row">
                    <div
                        class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
                        <div class="login-brand">
                            <img src="<?php echo e(asset('img/logo_blesscon.svg')); ?>" alt="logo" width="300">
                        </div>

                        <div class="card card-primary">
                            <div class="card-header">
                                <h4>Pengiriman Produk Bata Ringan (Merek Blesscon atau Superior)</h4>
                            </div>

                            <div class="card-body">

                                <div class="form-group">
                                    
                                    <?php
                                        $sessionData = session('form_pengiriman', []);
                                    ?>
                                    <form method="POST" id="formSurveyPengiriman"
                                        action="<?php echo e(route('post-form-pertanyaan-pengiriman')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php $__currentLoopData = $pertanyaanFormPengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="margin-bottom: 20px;">
                                                <strong><?php echo e($pertanyaan->pertanyaan); ?></strong><br>

                                                <?php
                                                    $tipeId = $pertanyaan->tipePertanyaan->id ?? null;
                                                    $jawabanUtama =
                                                        $sessionData['pertanyaan_' . $pertanyaan->id] ?? null;
                                                ?>

                                                <?php switch($tipeId):
                                                    case (1): ?>
                                                        
                                                        <?php $__currentLoopData = $pertanyaan->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $isOther = $option->is_other;
                                                                $isChecked =
                                                                    $jawabanUtama === strval($option->id) ||
                                                                    $jawabanUtama === 'other_' . $option->id;
                                                            ?>
                                                            <?php if($isOther): ?>
                                                                <label>
                                                                    <input type="radio"
                                                                        name="pertanyaan_<?php echo e($pertanyaan->id); ?>"
                                                                        value="other_<?php echo e($option->id); ?>"
                                                                        onchange="toggleOtherInput(this, '<?php echo e($pertanyaan->id); ?>')"
                                                                        <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                    Lainnya:
                                                                    <input type="text"
                                                                        name="pertanyaan_<?php echo e($pertanyaan->id); ?>_other"
                                                                        id="other_input_<?php echo e($pertanyaan->id); ?>"
                                                                        class="form-control mt-1"
                                                                        style="<?php echo e($isChecked ? '' : 'display: none;'); ?>"
                                                                        placeholder="Tuliskan jawaban Anda"
                                                                        value="<?php echo e($sessionData['pertanyaan_' . $pertanyaan->id . '_other'] ?? ''); ?>">
                                                                </label>
                                                            <?php else: ?>
                                                                <label>
                                                                    <input type="radio"
                                                                        name="pertanyaan_<?php echo e($pertanyaan->id); ?>"
                                                                        value="<?php echo e($option->id); ?>"
                                                                        <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                    <?php echo e($option->options ?? 'Opsi'); ?>

                                                                </label><br>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php break; ?>

                                                    <?php case (2): ?>
                                                        
                                                        <?php
                                                            $jawabanCheckbox = $jawabanUtama ?? [];
                                                            if (!is_array($jawabanCheckbox)) {
                                                                $jawabanCheckbox = [$jawabanCheckbox];
                                                            }
                                                        ?>
                                                        <?php $__currentLoopData = $pertanyaan->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $isOther = $option->is_other;
                                                                $isChecked =
                                                                    in_array(strval($option->id), $jawabanCheckbox) ||
                                                                    in_array('other_' . $option->id, $jawabanCheckbox);
                                                            ?>
                                                            <?php if($isOther): ?>
                                                                <label>
                                                                    <input type="checkbox"
                                                                        name="pertanyaan_<?php echo e($pertanyaan->id); ?>[]"
                                                                        value="other_<?php echo e($option->id); ?>"
                                                                        onchange="toggleOtherInput(this, '<?php echo e($pertanyaan->id); ?>_<?php echo e($option->id); ?>')"
                                                                        <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                    Lainnya:
                                                                    <input type="text"
                                                                        name="pertanyaan_<?php echo e($pertanyaan->id); ?>_other_<?php echo e($option->id); ?>"
                                                                        id="other_input_<?php echo e($pertanyaan->id); ?>_<?php echo e($option->id); ?>"
                                                                        class="form-control mt-1"
                                                                        style="<?php echo e($isChecked ? '' : 'display: none;'); ?>"
                                                                        placeholder="Tuliskan jawaban Anda"
                                                                        value="<?php echo e($sessionData['pertanyaan_' . $pertanyaan->id . '_other_' . $option->id] ?? ''); ?>">
                                                                </label>
                                                            <?php else: ?>
                                                                <label>
                                                                    <input type="checkbox"
                                                                        name="pertanyaan_<?php echo e($pertanyaan->id); ?>[]"
                                                                        value="<?php echo e($option->id); ?>"
                                                                        <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                    <?php echo e($option->options ?? 'Opsi'); ?>

                                                                </label><br>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php break; ?>

                                                    <?php case (3): ?>
                                                        
                                                        <input type="text" name="pertanyaan_<?php echo e($pertanyaan->id); ?>"
                                                            class="form-control" value="<?php echo e($jawabanUtama); ?>">
                                                    <?php break; ?>

                                                    <?php case (4): ?>
                                                        
                                                        <textarea name="pertanyaan_<?php echo e($pertanyaan->id); ?>" class="form-control"><?php echo e($jawabanUtama); ?></textarea>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <p><i>Tipe pertanyaan tidak dikenali (ID: <?php echo e($tipeId); ?>)</i></p>
                                                <?php endswitch; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="form-group d-flex justify-content-between">
                                            <a href="#" class="btn btn-outline-warning"
                                                onclick="document.getElementById('formSurveyPengiriman').reset(); return false;">Clear
                                                Form</a>

                                            <div class="d-flex" style="gap: 10px;">
                                                <a href="<?php echo e(route('form-pertanyaan-harga')); ?>"
                                                    class="btn btn-light">Back</a>
                                                <button type="submit" class="btn btn-primary">Next</button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
        </section>
    </div>

    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('library/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/popper.js/dist/umd/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('library/tooltip.js/dist/umd/tooltip.js')); ?>"></script>
    <script src="<?php echo e(asset('library/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/jquery.nicescroll/dist/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/stisla.js')); ?>"></script>

    <!-- JS Libraies -->

    <script>
        document.querySelector('form').addEventListener('submit', function(e) {
            let isValid = true;

            document.querySelectorAll('input[name="required_checkbox[]"]').forEach(function(hiddenInput) {
                let id = hiddenInput.value;
                let checkboxes = document.querySelectorAll('.checkbox-group-' + id);
                let checked = Array.from(checkboxes).some(cb => cb.checked);

                if (!checked) {
                    isValid = false;
                    alert('Mohon pilih minimal satu opsi untuk pertanyaan wajib.');
                }
            });

            if (!isValid) {
                e.preventDefault();
            }
        });
    </script>
    <!-- Page Specific JS File -->

    <!-- Template JS File -->
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>




</html>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/form-pertanyaan-pengiriman.blade.php ENDPATH**/ ?>