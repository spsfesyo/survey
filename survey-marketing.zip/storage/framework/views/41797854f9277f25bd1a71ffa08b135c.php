<footer class="main-footer">
    <div class="footer-left">
        
    </div>
    <div class="footer-right">
        
    </div>
</footer>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/footer.blade.php ENDPATH**/ ?>