  <div class="simple-footer">
      
  </div>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/auth-footer.blade.php ENDPATH**/ ?>