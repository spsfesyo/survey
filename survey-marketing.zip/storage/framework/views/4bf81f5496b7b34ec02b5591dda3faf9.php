<?php $__env->startSection('title', '404'); ?>

<?php $__env->startPush('style'); ?>
    <!-- CSS Libraries -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="page-error">
        <div class="page-inner">
            <h1>404</h1>
            <div class="page-description">
                The page you were looking for could not be found.
            </div>
            <div class="page-search">
                <form>
                    
                <div class="mt-3">
                    <a href="<?php echo e(route('home')); ?>">Back to Home</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- JS Libraies -->

    <!-- Page Specific JS File -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\survey-marketing\resources\views/errors/404.blade.php ENDPATH**/ ?>