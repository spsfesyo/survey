<div class="simple-footer mt-5">
    
</div>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/error-footer.blade.php ENDPATH**/ ?>