
<div class="chart-container mb-4">
    <canvas id="barChart<?php echo e($chartId); ?>" width="400" height="400"></canvas>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    const barCtx<?php echo e($chartId); ?> = document.getElementById('barChart<?php echo e($chartId); ?>').getContext('2d');
    new Chart(barCtx<?php echo e($chartId); ?>, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: '<?php echo e($label ?? "Jumlah Jawaban"); ?>',
                data: <?php echo json_encode($values); ?>,
                backgroundColor: <?php echo json_encode($colors ?? ['#36A2EB']); ?>,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<div class="chart-container mb-4">
    <canvas id="barChart<?php echo e($chartId); ?>" width="400" height="400"></canvas>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    const barCtx<?php echo e($chartId); ?> = document.getElementById('barChart<?php echo e($chartId); ?>').getContext('2d');
    new Chart(barCtx<?php echo e($chartId); ?>, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: '<?php echo e($label ?? "Jumlah Jawaban"); ?>',
                data: <?php echo json_encode($values); ?>,
                backgroundColor: <?php echo json_encode($colors ?? ['#36A2EB']); ?>,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/Charts/bar.blade.php ENDPATH**/ ?>