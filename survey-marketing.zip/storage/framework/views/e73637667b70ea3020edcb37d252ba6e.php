 <div class="login-brand">
     <img src="<?php echo e(asset('img/logo_blesscon.svg')); ?>"
         alt="logo"
         width="300">
 </div>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/auth-header.blade.php ENDPATH**/ ?>