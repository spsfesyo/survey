
<div class="chart-container mb-4">
    <canvas id="pieChart<?php echo e($chartId); ?>" width="400" height="400"></canvas>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    const pieCtx<?php echo e($chartId); ?> = document.getElementById('pieChart<?php echo e($chartId); ?>').getContext('2d');
    new Chart(pieCtx<?php echo e($chartId); ?>, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Data',
                data: <?php echo json_encode($values); ?>,
                backgroundColor: <?php echo json_encode($colors ?? ['#FF6384', '#36A2EB', '#FFCE56', '#9966FF', '#4BC0C0']); ?>

            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/components/Charts/pie.blade.php ENDPATH**/ ?>