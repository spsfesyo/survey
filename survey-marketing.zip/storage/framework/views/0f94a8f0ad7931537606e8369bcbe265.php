<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Form Pertanyaan</title>

    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- CSS Libraries -->
    <style>
        body {
            background-image: linear-gradient(120deg, #e0c3fc 0%, #8ec5fc 100%) !important;
        }

        .section {
            background-color: transparent !important;
        }
    </style>
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">

    <!-- Start GA -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-94034622-3');
    </script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- /END GA -->
</head>

<body>
    <div id="app">
        <section class="section">
            <div class="container mt-5">
                <div class="row">
                    <div
                        class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
                        <div class="login-brand">
                            <img src="<?php echo e(asset('img/logo_blesscon.svg')); ?>" alt="logo" width="300">
                        </div>

                        <div class="card card-primary">
                            <div class="card-header">
                                <h4>Pelayanan/Service Produk Bata Ringan (Merek Blesscon atau Superior)</h4>
                            </div>

                            <div class="card-body">
                                <?php
                                    $sessionData = session('form_pelayanan', []);
                                ?>
                                <form id="formSurveyPelayanan" method="POST"
                                    action="<?php echo e(route('post-form-pertanyaan-pelayanan')); ?>">
                                    <?php echo csrf_field(); ?>

                                    <?php $__currentLoopData = $pertanyaanFormPelayanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="margin-bottom: 20px;">
                                            <strong><?php echo e($pertanyaan->pertanyaan); ?></strong><br>

                                            <?php
                                                $tipeId = (int) ($pertanyaan->tipePertanyaan->id ?? null);
                                                $jawabanUtama = $sessionData['pertanyaan_' . $pertanyaan->id] ?? null;
                                            ?>

                                            <?php switch($tipeId):
                                                case (1): ?>
                                                    
                                                    <?php $__currentLoopData = $pertanyaan->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $isOther = $option->is_other;
                                                            $isChecked =
                                                                $jawabanUtama === strval($option->id) ||
                                                                $jawabanUtama === 'other_' . $option->id;
                                                        ?>
                                                        <?php if($isOther): ?>
                                                            <label>
                                                                <input type="radio" name="pertanyaan_<?php echo e($pertanyaan->id); ?>"
                                                                    value="other_<?php echo e($option->id); ?>"
                                                                    <?php echo e($loop->first ? 'required' : ''); ?>

                                                                    onchange="toggleOtherInput(this, '<?php echo e($pertanyaan->id); ?>')"
                                                                    <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                Lainnya:
                                                                <input type="text"
                                                                    name="pertanyaan_<?php echo e($pertanyaan->id); ?>_other"
                                                                    id="other_input_<?php echo e($pertanyaan->id); ?>"
                                                                    class="form-control mt-1"
                                                                    style="<?php echo e($isChecked ? '' : 'display: none;'); ?>"
                                                                    placeholder="Tuliskan jawaban Anda"
                                                                    value="<?php echo e($sessionData['pertanyaan_' . $pertanyaan->id . '_other'] ?? ''); ?>">
                                                            </label>
                                                        <?php else: ?>
                                                            <label>
                                                                <input type="radio" name="pertanyaan_<?php echo e($pertanyaan->id); ?>"
                                                                    value="<?php echo e($option->id); ?>"
                                                                    <?php echo e($loop->first ? 'required' : ''); ?>

                                                                    <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                <?php echo e($option->options ?? 'Opsi'); ?>

                                                            </label><br>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php break; ?>

                                                <?php case (2): ?>
                                                    
                                                    <?php
                                                        $jawabanCheckbox = $jawabanUtama ?? [];
                                                        if (!is_array($jawabanCheckbox)) {
                                                            $jawabanCheckbox = [$jawabanCheckbox];
                                                        }
                                                    ?>
                                                    <?php $__currentLoopData = $pertanyaan->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $isOther = $option->is_other;
                                                            $isChecked =
                                                                in_array(strval($option->id), $jawabanCheckbox) ||
                                                                in_array('other_' . $option->id, $jawabanCheckbox);
                                                        ?>
                                                        <?php if($isOther): ?>
                                                            <label>
                                                                <input type="checkbox"
                                                                    class="checkbox-group-<?php echo e($pertanyaan->id); ?>"
                                                                    name="pertanyaan_<?php echo e($pertanyaan->id); ?>[]"
                                                                    value="other_<?php echo e($option->id); ?>"
                                                                    onchange="toggleOtherInput(this, '<?php echo e($pertanyaan->id); ?>_<?php echo e($option->id); ?>')"
                                                                    <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                Lainnya:
                                                                <input type="text"
                                                                    name="pertanyaan_<?php echo e($pertanyaan->id); ?>_other_<?php echo e($option->id); ?>"
                                                                    id="other_input_<?php echo e($pertanyaan->id); ?>_<?php echo e($option->id); ?>"
                                                                    class="form-control mt-1"
                                                                    style="<?php echo e($isChecked ? '' : 'display: none;'); ?>"
                                                                    placeholder="Tuliskan jawaban Anda"
                                                                    value="<?php echo e($sessionData['pertanyaan_' . $pertanyaan->id . '_other_' . $option->id] ?? ''); ?>">
                                                            </label>
                                                        <?php else: ?>
                                                            <label>
                                                                <input type="checkbox"
                                                                    class="checkbox-group-<?php echo e($pertanyaan->id); ?>"
                                                                    name="pertanyaan_<?php echo e($pertanyaan->id); ?>[]"
                                                                    value="<?php echo e($option->id); ?>"
                                                                    <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                                <?php echo e($option->options ?? 'Opsi'); ?>

                                                            </label><br>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <input type="hidden" name="required_checkbox[]"
                                                        value="<?php echo e($pertanyaan->id); ?>">
                                                <?php break; ?>

                                                <?php case (3): ?>
                                                    
                                                    <input type="text" name="pertanyaan_<?php echo e($pertanyaan->id); ?>"
                                                        class="form-control"
                                                        value="<?php echo e(old('pertanyaan_' . $pertanyaan->id, $jawabanUtama)); ?>"
                                                        required>
                                                <?php break; ?>

                                                <?php case (4): ?>
                                                    
                                                    <textarea name="pertanyaan_<?php echo e($pertanyaan->id); ?>" class="form-control" rows="3" required><?php echo e(old('pertanyaan_' . $pertanyaan->id, $jawabanUtama)); ?></textarea>
                                                <?php break; ?>

                                                <?php default: ?>
                                                    <p class="text-danger">Tipe pertanyaan tidak dikenali.</p>
                                            <?php endswitch; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group d-flex justify-content-between">
                                        <a href="#" class="btn btn-outline-warning"
                                            onclick="document.getElementById('formSurveyPelayanan').reset(); return false;">Clear
                                            Form</a>

                                        <div class="d-flex" style="gap: 10px;">
                                            <a href="<?php echo e(route('form-pertanyaan-pengiriman')); ?>"
                                                class="btn btn-light">Back</a>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('library/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/popper.js/dist/umd/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('library/tooltip.js/dist/umd/tooltip.js')); ?>"></script>
    <script src="<?php echo e(asset('library/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/jquery.nicescroll/dist/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/stisla.js')); ?>"></script>

    <!-- JS Libraies -->
    <script>
        document.querySelector('form').addEventListener('submit', function(e) {
            let isValid = true;

            document.querySelectorAll('input[name="required_checkbox[]"]').forEach(function(hiddenInput) {
                let id = hiddenInput.value;
                let checkboxes = document.querySelectorAll('.checkbox-group-' + id);
                let checked = Array.from(checkboxes).some(cb => cb.checked);

                if (!checked) {
                    isValid = false;
                    alert('Mohon pilih minimal satu opsi untuk pertanyaan wajib.');
                }
            });

            if (!isValid) {
                e.preventDefault();
            }
        });
    </script>   
    <!-- Page Specific JS File -->

    <!-- Template JS File -->
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>


    <script>
        function toggleOtherInput(input, id) {
            const textInput = document.getElementById('other_input_' + id);
            if (!textInput) return;

            if (input.type === 'radio') {
                // Sembunyikan semua input lainnya dengan nama serupa
                document.querySelectorAll(`input[id^="other_input_${id}"]`).forEach(el => el.style.display = 'none');
            }

            textInput.style.display = input.checked ? 'inline-block' : 'none';

            // Kosongkan input jika tidak dicentang
            if (!input.checked) {
                textInput.value = '';
            }
        }
    </script>


    <script>
        <?php if(session('success')): ?>
            Swal.fire({
                title: 'Sukses!',
                text: '<?php echo e(session('success')); ?>',
                icon: 'success',
                confirmButtonText: 'OK'
            });
        <?php endif; ?>
    </script>

</html>
<?php /**PATH C:\laragon\www\survey-marketing\resources\views/form-pertanyaan-pelayanan.blade.php ENDPATH**/ ?>